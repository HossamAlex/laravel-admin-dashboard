# laravel-admin-dashboard
AdminLTE - Laravel Admin Dashboard - Laravel 5.7

Prerequisites
After cloning the repository, go to the root folder and run the following command/s, 

• composer install

• composer update

Next steps:
  
• Rename .env.example to .env and provide your database details.  

• Register

• Login

AdminLTE Template: https://adminlte.io/
