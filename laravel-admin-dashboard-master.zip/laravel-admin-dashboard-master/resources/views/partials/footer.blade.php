<div>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://github.com/EgHoxhaj"> Eg.Hoxhaj</a></strong>
    </footer>
</div>
